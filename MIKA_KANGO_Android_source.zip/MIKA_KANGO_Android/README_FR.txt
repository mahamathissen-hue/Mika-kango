MIKA KANGO — projet Android de démarrage
Signature : par Hissen wong

Ce dossier est un projet Android Studio (Java + WebView), pas encore un APK compilé.

Prototype inclus :
- identité MIKA KANGO avec le logo fourni
- interface mobile aux couleurs orange et bleu
- fil unique de forum commun
- messages de démonstration locaux
- aperçu local des images et vidéos choisies
- sélection de fichiers depuis Android

IMPORTANT : les messages de cette première maquette restent sur l'appareil.
Le serveur temps réel, les comptes, la synchronisation entre téléphones, les notifications push,
les appels et le stockage partagé doivent être développés et configurés avant une mise en service.
Aucun compte ou serveur n'est actuellement configuré.

Pour compiler :
1. Installer Android Studio sur un ordinateur.
2. Ouvrir le dossier MIKA_KANGO_Android.
3. Laisser Android Studio synchroniser Gradle et installer Android SDK 35.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).

Application ID : com.hissenwong.mikakango
Minimum Android : 6.0 (API 23)
